#!/usr/bin/env python

import numpy as np
data = np.genfromtxt('square_cuda.cgh',delimiter=' ')

import matplotlib.pyplot as plt

plt.imshow(data,origin='lower')
plt.savefig('square_cuda.png',origin='lower')
plt.show()
