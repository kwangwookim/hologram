#include <iostream>
#include <fstream>

using namespace std;

int main()
{

    // Draw Object
    ofstream SaveFile("square.obj");

    double x,y;
    double z = -100.0;
    double A = 1.0;

    for ( int j=0;j<20;j++)
     {
        for (int i=0;i<20;i++)
           {
              x = 2.4 + 0.01*i;
              y = 2.4 + 0.01*j;
              SaveFile << x << " " << y << " " << z << " " << A << endl;
           }

     }

//
//
//    for ( int j=0;j<60;j++)
//     {
//        for (int i=0;i<20;i++)
//           {
//              x = 2.0 + 0.05*i;
//              y = 0.05*j;
//              SaveFile << x << " " << y << " " << z << " " << A << endl;
//           }
//
//     }
//


    SaveFile.close();
}

