#!/usr/bin/env python

import Image
import numpy as np

im = Image.open("circle.png")
col,row =  im.size
data = np.zeros((row*col, 4))
pixels = im.load()
for i in range(row):
    for j in range(col):
        r,g,b =  pixels[i,j]
        data[i*col + j,:] = 5.0/col*i,5.0-5.0/row*j,-100.0,r


np.savetxt('circle.obj', data)


