#!/usr/bin/env python

import numpy as np
data = np.genfromtxt('square.obj',delimiter=' ')

import matplotlib.pyplot as plt
plt.plot(data[:,0], data[:,1], 'ro')
plt.axis([0, 5, 0, 5])
plt.show()
