#!/usr/bin/env python
import time
import numpy
import sys
import Image
import matplotlib.pyplot as plt

from numpy import genfromtxt

Nx = 149800
Ny = 149800
Niter = Ny/350*3 

im = Image.new('L',(Nx,Ny))
pixels = im.load()


tempmax = []
tempmin = []
historange = numpy.arange(-5,265,10)
temphisto = numpy.zeros(26)

for n in range(0,Niter):
    start = time.time()
    filename = '/media/jspark/8CCCDBCDCCDBB026/CGH/sourceCode/cgh_result/Color_RGB/'+str(n)+'.cgh2'
    cgh = genfromtxt(filename,delimiter=' ')

    tempmax.append(cgh.max())
    tempmin.append(cgh.min())

    temphisto+=numpy.histogram(cgh.flatten(),historange)[0]
    if n % 3 == 0:
        dy = 116
        for i in range((n/3)*350,(n/3)*350+dy):
        
            for j in range(0,Nx):
                pixels[j,i]=(cgh[i-(n/3)*350][j])
    elif n % 3 == 1:
        dy = 117
        for i in range(116+(n/3)*350,116+(n/3)*350+dy):
        
            for j in range(0,Nx):
                pixels[j,i]=(cgh[i-(n/3)*350-116][j])
    elif n % 3 == 2:
        dy = 117
        for i in range(233+(n/3)*350,233+(n/3)*350+dy):
        
            for j in range(0,Nx):
                pixels[j,i]=(cgh[i-(n/3)*350-233][j])



    end = time.time()
    print(n,end-start)

tempmaxarr = numpy.asarray(tempmax)
tempminarr = numpy.asarray(tempmin)
globmax = tempmaxarr.max()
globmin = tempminarr.min()
print(globmax,globmin)

print(temphisto,historange)

im.save ('/media/jspark/8CCCDBCDCCDBB026/CGH/sourceCode/cgh_result/Color_RGB/Color_RGB.bmp')


