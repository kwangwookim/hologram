#!/usr/bin/env python

import numpy
import sys
import Image
import matplotlib.pyplot as plt

import glob
filelist =  glob.glob("result/Cube2/*.cgh2")


from numpy import genfromtxt

for name in filelist:
    cgh = genfromtxt(name,delimiter=' ')


    im = Image.fromarray ((cgh*255).astype (numpy.uint8))
    im.save (name.replace('.cgh2','.bmp'))
    im.show ()
