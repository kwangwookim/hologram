#!/usr/bin/env python

import numpy
import sys
import Image
import matplotlib.pyplot as plt

from numpy import genfromtxt
data = genfromtxt(sys.argv [1],delimiter=' ')
cgh = ( data - data.min ())/(data.max () - data.min ())

im = Image.fromarray ((cgh*255).astype (numpy.uint8))
im.save (sys.argv [2])
im.show ()
