#!/usr/bin/env python

import numpy
import sys
import Image
import matplotlib.pyplot as plt

from numpy import genfromtxt
cgh = genfromtxt(sys.argv [1],delimiter=' ')

im = Image.fromarray ((cgh*255).astype (numpy.uint8))
im.save (sys.argv [2])
im.show ()
