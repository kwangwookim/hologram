#!/usr/bin/env python
import time
import numpy
import sys
import Image
import matplotlib.pyplot as plt

from numpy import genfromtxt

Nx = 1500
Ny = 1500
Niter = 150 
dy = Ny/Niter

im = Image.new('L',(Nx,Ny))
pixels = im.load()


tempmax = []
tempmin = []
historange = numpy.arange(-5,265,10)
temphisto = numpy.zeros(26)

for n in range(0,Niter):
    start = time.time()
    filename = '/home/jspark/work/cuda/test/Cgh_Cuda/ver0.5_randomphase/test2/'+str(n)+'.cgh2'
    cgh = genfromtxt(filename,delimiter=' ')

    tempmax.append(cgh.max())
    tempmin.append(cgh.min())

    temphisto+=numpy.histogram(cgh.flatten(),historange)[0]

    for i in range(n*dy,(n+1)*dy):
        
        for j in range(0,Nx):
            pixels[j,i]=(cgh[i-n*dy][j])
    end = time.time()
    print(n,end-start)

tempmaxarr = numpy.asarray(tempmax)
tempminarr = numpy.asarray(tempmin)
globmax = tempmaxarr.max()
globmin = tempminarr.min()
print(globmax,globmin)

print(temphisto,historange)

im.save ('/home/jspark/work/cuda/test/Cgh_Cuda/ver0.5_randomphase/test2/test.bmp')


