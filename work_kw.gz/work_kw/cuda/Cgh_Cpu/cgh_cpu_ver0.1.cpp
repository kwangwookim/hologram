#include <iostream>
#include <fstream>
#include <cmath>
#include <boost/timer.hpp>
#include <ctime>

using namespace std;


// Set parameter

const int N_obj = 19246;
const int Nx = 100;
const int Ny = 100;
const double lambda = 6.5E-5;
const double Lx = 5.0;
const double Ly = 5.0;
const double angle = M_PI / 180.0 * (0.0);


// Set constants

double px = Lx / Nx;
double py = Ly / Ny;
double k = 2*M_PI / lambda;
 

// object structure

struct ObjArray
       {
          double x;
          double y;
          double z;
          double A;
       };

ObjArray object[N_obj];
 

// Define CGH fucntion

double holo(int nx,int ny)
    {
       double hol = 0.0;
       
       for (int i=0; i<N_obj; i++)
       {
           double distance  =  sqrt(  pow( px * nx - object[i].x ,2)
                                    + pow( py * ny - object[i].y ,2)
                                    + pow( object[i].z ,2)
                                   ); 
           
           hol+= cos( k * (distance - py * ny * sin(angle)) ); 
            
       }  
       return hol / N_obj;
     }



int main()
{


    // Reading Object file
    
    boost::timer t;
    t.restart();

    ifstream infile("ABC.obj");
      
    for (int i=0; i<N_obj; i++)
        {
           infile >> object[i].x >> object[i].y >> object[i].z >> object[i].A;
        }

    infile.close();

    double elapsed = t.elapsed();
    cout << "Reading..  " << elapsed << endl;


    t.restart();

    ofstream SaveCGH("ABC_cpu.cgh");

    for (int j=0; j<Ny; j++)
       {

           for (int i=0; i<Nx; i++)
               {
                 SaveCGH << holo(i,j) << ",";
               }

           SaveCGH << endl;
       }     
    SaveCGH.close();

    elapsed = t.elapsed();
    cout << "CGH calcuation..  " << elapsed << endl;
    

}
