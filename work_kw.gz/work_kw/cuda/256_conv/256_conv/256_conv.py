#!/usr/bin/env python

import time
import numpy as np
import sys
import Image
import matplotlib.pyplot as plt

import glob
filelist =  glob.glob("/home/jspark/work/cuda/test/Cgh_Cuda/ver0.5_randomphase/test2/*.cgh")

from numpy import genfromtxt


tempmax = []
tempmin = []
n=0
for name in filelist:
    start = time.time()
    data = genfromtxt(name,delimiter=' ')
    tempmax.append(data.max())
    tempmin.append(data.min())
    end = time.time()
    print('reading..',n,end-start)
    n=n+1
   


tempmaxarr = np.asarray(tempmax)
tempminarr = np.asarray(tempmin)
globmax = tempmaxarr.max()
globmin = tempminarr.min()
delta = globmax - globmin
print(globmax,globmin,delta)
print('reading completed')

n=0
for name in filelist:
    
    start = time.time()
    data = genfromtxt(name,delimiter=' ')
    cgh_temp = 255.0*( data - globmin ) / delta
    cgh2 = np.round(cgh_temp,decimals=3)
    cgh = cgh2.astype(int)
    print('writing cgh2..',name)
    np.savetxt(name.replace('.cgh','.cgh2'),cgh,fmt='%u',delimiter=" ")
    end = time.time()
    print(n,end-start)
    n=n+1
