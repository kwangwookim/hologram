#!/usr/bin/env python

import numpy as np
import sys
import Image
import matplotlib.pyplot as plt

import glob
filelist =  glob.glob("result/Cube/*.cgh")

from numpy import genfromtxt


tempmax = []
tempmin = []
for name in filelist:
    data = genfromtxt(name,delimiter=' ')
    tempmax.append(data.max())
    tempmin.append(data.min())

tempmaxarr = np.asarray(tempmax)
tempminarr = np.asarray(tempmin)
globmax = tempmaxarr.max()
globmin = tempminarr.min()
delta = globmax - globmin

for name in filelist:

    data = genfromtxt(name,delimiter=' ')
    cgh_temp = ( data - globmin ) / delta
    cgh2 = np.rint(cgh_temp)
    cgh = cgh2.astype(int)

    np.savetxt(name.replace('.cgh','.cgh2'),cgh,fmt='%u',delimiter=" ")
