#!/usr/bin/env python

import numpy as np
import sys
import Image
import matplotlib.pyplot as plt

from numpy import genfromtxt
data = genfromtxt(sys.argv [1],delimiter=' ')
cgh_temp = ( data - data.min ())/(data.max () - data.min ())

cgh2 = np.rint(cgh_temp)
cgh = cgh2.astype(int)

np.savetxt(sys.argv[2],cgh,fmt='%u',delimiter=" ")
