#!/usr/bin/env python

import csv
import math

Nz = 20
Nr = 200
r = 0.5
arr = []


for i in range(0,Nz+1):
    theta = math.pi/2*i/Nz
    Nj = int(Nr*math.sin(theta))

    for j in range(0,Nj+1):
        phi = 2*math.pi*j/(Nj+0.01)
        x = round(3.5 + r*math.sin(theta)*math.cos(phi),4) 
        y = round(3.5 + r*math.sin(theta)*math.sin(phi),4)
        z = round(0.6 + r*math.cos(theta),4)
        A = 1
        arr.append([x,y,z,A])

        
for i in range(0,Nz+1):
    theta = math.pi/2*i/Nz
    Nj = int(Nr*math.sin(theta))

    for j in range(0,Nj+1):
        phi = math.pi*j/(Nj+0.01)
        x = round(3.5 + r*math.sin(theta)*math.cos(phi),4) 
        z = round(0.6 + r*math.sin(theta)*math.sin(phi),4)
        y = round(3.5 + r*math.cos(theta),4)
        A = 1
        arr.append([x,y,z,A])

for i in range(0,Nz+1):
    theta = math.pi/2*i/Nz
    Nj = int(Nr*math.sin(theta))

    for j in range(0,Nj+1):
        phi = math.pi*j/(Nj+0.01)
        x = round(3.5 + r*math.sin(theta)*math.cos(phi),4) 
        z = round(0.6 + r*math.sin(theta)*math.sin(phi),4)
        y = round(3.5 - r*math.cos(theta),4)
        A = 1
        arr.append([x,y,z,A])


with open('sphere2.obj','wb') as f:
    writer = csv.writer(f, delimiter = ' ')
    writer.writerows(arr)



