#!/usr/bin/env python
import sys
import Image
import numpy as np

Lx = 4.5
Ly = 4.5
z = -4.0

im = Image.open(sys.argv[1])
row,col =  im.size
data = np.zeros((row*col, 4))
pixels = im.load()
for i in range(row):
    for j in range(col):
        g =  pixels[i,j]
        data[i*col + j,:] = Lx/col*i,Ly-Ly/row*j,z,g


np.savetxt(sys.argv[2], data)


