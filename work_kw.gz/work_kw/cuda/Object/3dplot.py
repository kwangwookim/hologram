#!/usr/bin/env python

import numpy as np
from mpl_toolkits.mplot3d import Axes3D
import sys
import Image
import matplotlib.pyplot as plt

fig = plt.figure()
ax = fig.add_subplot(111, projection='3d')

from numpy import genfromtxt
data = genfromtxt(sys.argv [1],delimiter=' ')

x = data[:,0]
y = data[:,1]
z = data[:,2]

ax.scatter(x,y,z)

ax.set_xlabel('X Label')
ax.set_ylabel('Y Label')
ax.set_zlabel('Z Label')

ax.set_xlim([0,4.5])
ax.set_ylim([0,4.5])
ax.set_zlim([0,4.5])


plt.show()

