#!/usr/bin/env python
import math
import numpy as np
from mpl_toolkits.mplot3d import Axes3D
import sys
import Image
import matplotlib.pyplot as plt

fig = plt.figure(figsize=(10,10))
ax = fig.add_subplot(111, projection='3d')
ax.set_axis_off()

from numpy import genfromtxt
data = genfromtxt(sys.argv [1],delimiter=' ')

x = data[:,0]-2.75
z = 4.5-data[:,1]-2.75
y = data[:,2]-3

ax.scatter(x,y,z)

n=0    
for i in range(-45,45,5):
    for j in range(-135,-45,5):

        ax.view_init(elev=-i,azim=j)
        ax.dist=abs(10/math.cos((j+90)/180*math.pi)/math.cos(i/180*math.pi))
        plt.savefig('Hogel/hogel%d.png'%n,dpi=20)
        n=n+1

#ax.set_xlabel('X Label')
#ax.set_ylabel('Y Label')
#ax.set_zlabel('Z Label')

#ax.set_xlim([0,4.5])
#ax.set_ylim([0,4.5])
#ax.set_zlim([0,4.5])


#plt.show()

