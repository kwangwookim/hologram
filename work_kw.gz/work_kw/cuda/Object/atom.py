#!/usr/bin/env python

import csv
import math

Nz = 20
Nr = 200
r = 0.2
arr = []


for i in range(0,Nz+1):
    theta = math.pi/2*i/Nz
    Nj = int(Nr*math.sin(theta))

    for j in range(0,Nj+1):
        phi = 2*math.pi*j/(Nj+0.01)
        x = round(1.5 + r*math.sin(theta)*math.cos(phi),4) 
        y = round(1.5 + r*math.sin(theta)*math.sin(phi),4)
        z = round(2 - r*math.cos(theta),4)
        A = 1
        arr.append([x,y,z,A])
for i in range(0,Nz+1):
    theta = math.pi/2*i/Nz
    Nj = int(Nr*math.sin(theta))

    for j in range(0,Nj+1):
        phi = 2*math.pi*j/(Nj+0.01)
        x = round(1.5 + r*math.sin(theta)*math.cos(phi),4) 
        y = round(1.5 + r*math.sin(theta)*math.sin(phi),4)
        z = round(2 + r*math.cos(theta),4)
        A = 1
        arr.append([x,y,z,A])

for i in range(0,Nz+1):
    theta = math.pi/2*i/Nz
    Nj = int(Nr*math.sin(theta))

    for j in range(0,Nj+1):
        phi = 2*math.pi*j/(Nj+0.01)
        x = round(1.5 + r*math.sin(theta)*math.cos(phi),4) 
        z = round(2 + r*math.sin(theta)*math.sin(phi),4)
        y = round(1.5 + r*math.cos(theta),4)
        A = 1
        arr.append([x,y,z,A])

for i in range(0,Nz+1):
    theta = math.pi/2*i/Nz
    Nj = int(Nr*math.sin(theta))

    for j in range(0,Nj+1):
        phi = 2*math.pi*j/(Nj+0.01)
        x = round(1.5 + r*math.sin(theta)*math.cos(phi),4) 
        z = round(2 + r*math.sin(theta)*math.sin(phi),4)
        y = round(1.5 - r*math.cos(theta),4)
        A = 1
        arr.append([x,y,z,A])

r = 0.7

for i in range(Nz,Nz+1):
    theta = math.pi/2*i/Nz
    Nj = int(Nr*math.sin(theta))

    for j in range(0,Nj+1):
        phi = 2*math.pi*j/(Nj+0.01)
        x = round(1.5 + r*math.sin(theta)*math.cos(phi),4) 
        y = round(1.5 + r*math.sin(theta)*math.sin(phi),4)
        z = round(2 - r*math.cos(theta),4)
        A = 1

        y2 = math.cos(math.pi/4)*(y-1.5) - math.sin(math.pi/4)*(z-2)+1.5
        z2 = math.sin(math.pi/4)*(y-1.5) + math.cos(math.pi/4)*(z-2)+2 
 
        arr.append([x,y2,z2,A])

    
    for j in range(0,Nj+1):
        phi = 2*math.pi*j/(Nj+0.01)
        x = round(1.5 + r*math.sin(theta)*math.cos(phi),4) 
        z = round(2 + r*math.sin(theta)*math.sin(phi),4)
        y = round(1.5 + r*math.cos(theta),4)
        A = 1
 
        x2 = math.cos(math.pi/4)*(x-1.5) - math.sin(math.pi/4)*(y-1.5)+1.5
        y2 = math.sin(math.pi/4)*(x-1.5) + math.cos(math.pi/4)*(y-1.5)+1.5 
        z2 = z
        x3 = math.cos(math.pi/4)*(x-1.5) + math.sin(math.pi/4)*(y-1.5)+1.5
        y3 = -math.sin(math.pi/4)*(x-1.5) + math.cos(math.pi/4)*(y-1.5)+1.5 
        z3 = z

        x4 = x2
        y4 = math.cos(math.pi/4)*(y2-1.5) - math.sin(math.pi/4)*(z2-2)+1.5
        z4 = math.sin(math.pi/4)*(y2-1.5) + math.cos(math.pi/4)*(z2-2)+2 
        x5 = x3
        y5 = math.cos(math.pi/4)*(y3-1.5) - math.sin(math.pi/4)*(z3-2)+1.5
        z5 = math.sin(math.pi/4)*(y3-1.5) + math.cos(math.pi/4)*(z3-2)+2 
 
        arr.append([x4,y4,z4,A])
        arr.append([x5,y5,z5,A])
r = 0.715

for i in range(Nz,Nz+1):
    theta = math.pi/2*i/Nz
    Nj = int(Nr*math.sin(theta))

    for j in range(0,Nj+1):
        phi = 2*math.pi*j/(Nj+0.01)
        x = round(1.5 + r*math.sin(theta)*math.cos(phi),4) 
        y = round(1.5 + r*math.sin(theta)*math.sin(phi),4)
        z = round(2 - r*math.cos(theta),4)
        A = 1

        y2 = math.cos(math.pi/4)*(y-1.5) - math.sin(math.pi/4)*(z-2)+1.5
        z2 = math.sin(math.pi/4)*(y-1.5) + math.cos(math.pi/4)*(z-2)+2 
 
        arr.append([x,y2,z2,A])

    
    for j in range(0,Nj+1):
        phi = 2*math.pi*j/(Nj+0.01)
        x = round(1.5 + r*math.sin(theta)*math.cos(phi),4) 
        z = round(2 + r*math.sin(theta)*math.sin(phi),4)
        y = round(1.5 + r*math.cos(theta),4)
        A = 1
 
        x2 = math.cos(math.pi/4)*(x-1.5) - math.sin(math.pi/4)*(y-1.5)+1.5
        y2 = math.sin(math.pi/4)*(x-1.5) + math.cos(math.pi/4)*(y-1.5)+1.5 
        z2 = z
        x3 = math.cos(math.pi/4)*(x-1.5) + math.sin(math.pi/4)*(y-1.5)+1.5
        y3 = -math.sin(math.pi/4)*(x-1.5) + math.cos(math.pi/4)*(y-1.5)+1.5 
        z3 = z

        x4 = x2
        y4 = math.cos(math.pi/4)*(y2-1.5) - math.sin(math.pi/4)*(z2-2)+1.5
        z4 = math.sin(math.pi/4)*(y2-1.5) + math.cos(math.pi/4)*(z2-2)+2 
        x5 = x3
        y5 = math.cos(math.pi/4)*(y3-1.5) - math.sin(math.pi/4)*(z3-2)+1.5
        z5 = math.sin(math.pi/4)*(y3-1.5) + math.cos(math.pi/4)*(z3-2)+2 
 
        arr.append([x4,y4,z4,A])
        arr.append([x5,y5,z5,A])

r = 0.73

for i in range(Nz,Nz+1):
    theta = math.pi/2*i/Nz
    Nj = int(Nr*math.sin(theta))

    for j in range(0,Nj+1):
        phi = 2*math.pi*j/(Nj+0.01)
        x = round(1.5 + r*math.sin(theta)*math.cos(phi),4) 
        y = round(1.5 + r*math.sin(theta)*math.sin(phi),4)
        z = round(2 - r*math.cos(theta),4)
        A = 1

        y2 = math.cos(math.pi/4)*(y-1.5) - math.sin(math.pi/4)*(z-2)+1.5
        z2 = math.sin(math.pi/4)*(y-1.5) + math.cos(math.pi/4)*(z-2)+2 
 
        arr.append([x,y2,z2,A])

    
    for j in range(0,Nj+1):
        phi = 2*math.pi*j/(Nj+0.01)
        x = round(1.5 + r*math.sin(theta)*math.cos(phi),4) 
        z = round(2 + r*math.sin(theta)*math.sin(phi),4)
        y = round(1.5 + r*math.cos(theta),4)
        A = 1
 
        x2 = math.cos(math.pi/4)*(x-1.5) - math.sin(math.pi/4)*(y-1.5)+1.5
        y2 = math.sin(math.pi/4)*(x-1.5) + math.cos(math.pi/4)*(y-1.5)+1.5 
        z2 = z
        x3 = math.cos(math.pi/4)*(x-1.5) + math.sin(math.pi/4)*(y-1.5)+1.5
        y3 = -math.sin(math.pi/4)*(x-1.5) + math.cos(math.pi/4)*(y-1.5)+1.5 
        z3 = z

        x4 = x2
        y4 = math.cos(math.pi/4)*(y2-1.5) - math.sin(math.pi/4)*(z2-2)+1.5
        z4 = math.sin(math.pi/4)*(y2-1.5) + math.cos(math.pi/4)*(z2-2)+2 
        x5 = x3
        y5 = math.cos(math.pi/4)*(y3-1.5) - math.sin(math.pi/4)*(z3-2)+1.5
        z5 = math.sin(math.pi/4)*(y3-1.5) + math.cos(math.pi/4)*(z3-2)+2 
 
        arr.append([x4,y4,z4,A])
        arr.append([x5,y5,z5,A])


with open('atom.obj','wb') as f:
    writer = csv.writer(f, delimiter = ' ')
    writer.writerows(arr)



